import PetNutritionCalculator from "@/components/PetNutritionCalculator";
import { Helmet } from "react-helmet";
import { useLanguage } from "@/lib/languageContext";
import { useTheme } from "@/lib/themeContext";

export default function Home() {
  const { t } = useLanguage();
  const { theme } = useTheme();
  
  return (
    <>
      <Helmet>
        <title>{t('app.title')}</title>
        <meta name="description" content={t('app.subtitle')} />
      </Helmet>
      <div className={`min-h-screen py-8 ${theme === 'dark' ? 'bg-gray-900' : 'bg-[#f5f7fa]'}`}>
        <PetNutritionCalculator />
      </div>
    </>
  );
}
