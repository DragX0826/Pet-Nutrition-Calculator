// Life stage options for dogs
export const dogLifeStages = [
  { value: 'puppy-under-4m', label: 'Puppy (under 4 months)' },
  { value: 'puppy-4-12m', label: 'Puppy (4-12 months)' },
  { value: 'adult-unneutered', label: 'Adult (unneutered)' },
  { value: 'adult-neutered', label: 'Adult (neutered)' },
  { value: 'senior', label: 'Senior' },
  { value: 'pregnant', label: 'Pregnant' },
  { value: 'lactating', label: 'Lactating' },
  { value: 'weight-loss', label: 'Weight Loss' }
];

// Life stage options for cats
export const catLifeStages = [
  { value: 'kitten', label: 'Kitten' },
  { value: 'adult-unneutered', label: 'Adult (unneutered)' },
  { value: 'adult-neutered', label: 'Adult (neutered)' },
  { value: 'senior', label: 'Senior' },
  { value: 'pregnant', label: 'Pregnant' },
  { value: 'lactating', label: 'Lactating' },
  { value: 'weight-loss', label: 'Weight Loss' }
];

// Life stage options for hamsters
export const hamsterLifeStages = [
  { value: 'baby', label: 'Baby (under 2 months)' },
  { value: 'young', label: 'Young (2-4 months)' },
  { value: 'adult', label: 'Adult (4-12 months)' },
  { value: 'senior', label: 'Senior (over 1 year)' }
];

// Life stage options for parrots
export const parrotLifeStages = [
  { value: 'chick', label: 'Chick' },
  { value: 'juvenile', label: 'Juvenile' },
  { value: 'young-adult', label: 'Young Adult' },
  { value: 'adult', label: 'Adult' },
  { value: 'senior', label: 'Senior' }
];

// DER Factors (Daily Energy Requirement)
export const DERFactors = {
  dog: {
    'puppy-under-4m': 3.0,
    'puppy-4-12m': 2.5,
    'adult-unneutered': 1.8,
    'adult-neutered': 1.6,
    'senior': 1.4,
    'pregnant': 2.0,
    'lactating': 4.0,
    'weight-loss': 0.8
  },
  cat: {
    'kitten': 2.5,
    'adult-unneutered': 1.4,
    'adult-neutered': 1.2,
    'senior': 1.1,
    'pregnant': 2.0,
    'lactating': 3.0,
    'weight-loss': 0.8
  },
  hamster: {
    'baby': 2.0,
    'young': 1.8,
    'adult': 1.5,
    'senior': 1.2
  },
  parrot: {
    'chick': 2.5,
    'juvenile': 2.0,
    'young-adult': 1.7,
    'adult': 1.5,
    'senior': 1.3
  }
};

// Activity level multipliers
export const activityMultipliers = {
  low: 0.8,
  normal: 1.0,
  high: 1.2
};

// BCS adjustment factors
export const bcsAdjustmentFactors = {
  1: 1.2, // Very underweight - needs more calories
  2: 1.1,
  3: 1.05, // Underweight
  4: 1.0,
  5: 1.0, // Ideal weight
  6: 0.95,
  7: 0.9, // Overweight
  8: 0.8,
  9: 0.7 // Obese - needs fewer calories
};

// Nutrition standards (% of dry matter)
export const nutritionStandards = {
  dog: {
    protein: { min: 18, max: 30 },
    fat: { min: 10, max: 15 },
    carbohydrate: { min: 0, max: 50 }
  },
  cat: {
    protein: { min: 30, max: 45 },
    fat: { min: 15, max: 20 },
    carbohydrate: { min: 0, max: 30 }
  },
  hamster: {
    protein: { min: 16, max: 24 },
    fat: { min: 4, max: 7 },
    carbohydrate: { min: 45, max: 65 },
    fiber: { min: 6, max: 15 }
  },
  parrot: {
    protein: { min: 12, max: 18 },
    fat: { min: 4, max: 10 },
    carbohydrate: { min: 50, max: 70 },
    fiber: { min: 3, max: 8 }
  }
};

// BCS descriptions for dogs and cats
export const bcsDescriptions = {
  dog: {
    1: {
      title: 'Very Thin',
      description: 'Ribs, spine, and hip bones easily visible. No palpable fat. Obvious waist and abdominal tuck. Muscle loss present.'
    },
    3: {
      title: 'Underweight',
      description: 'Ribs easily palpable and may be visible. Top of lumbar vertebrae visible. Obvious waist and abdominal tuck.'
    },
    5: {
      title: 'Ideal',
      description: 'Ribs palpable without excess fat covering. Waist observed behind ribs when viewed from above. Abdomen tucked up when viewed from side.'
    },
    7: {
      title: 'Overweight',
      description: 'Ribs palpable with difficulty with moderate fat covering. Waist is discernible but not prominent. Abdominal tuck apparent.'
    },
    9: {
      title: 'Obese',
      description: 'Ribs not palpable under very heavy fat cover. Heavy fat deposits over lumbar spine and base of tail. No waist and abdominal distension present.'
    }
  },
  cat: {
    1: {
      title: 'Very Thin',
      description: 'Ribs visible on shorthaired cats; no palpable fat; severe abdominal tuck; lumbar vertebrae and wings of ilia easily palpated.'
    },
    3: {
      title: 'Underweight',
      description: 'Ribs easily palpable with minimal fat covering; lumbar vertebrae obvious; obvious waist behind ribs; minimal abdominal fat.'
    },
    5: {
      title: 'Ideal',
      description: 'Well-proportioned; waist observed behind ribs; ribs palpable with slight fat covering; abdominal fat pad minimal.'
    },
    7: {
      title: 'Overweight',
      description: 'Ribs not easily palpable with moderate fat covering; waist poorly discernible; obvious rounding of abdomen; moderate abdominal fat pad.'
    },
    9: {
      title: 'Obese',
      description: 'Ribs not palpable under heavy fat cover; heavy fat deposits over lumbar area, face and limbs; distended abdomen with no waist; extensive abdominal fat deposits.'
    }
  }
};

// Define the PetType type
export type PetType = 'dog' | 'cat' | 'hamster' | 'parrot';

// Function to get nutrition recommendations based on pet type
export const getNutritionRecommendations = (petType: PetType) => {
  // If the pet type exists in our standards, return it, otherwise default to dog
  return nutritionStandards[petType] || nutritionStandards['dog'];
};

// Sample recommended products (can be replaced with real data from API)
export const recommendedProducts = {
  dog: [
    {
      id: 1,
      name: 'Premium Dog Formula',
      description: 'Ideal for adult dogs, balanced nutrition',
      rating: 4.7
    }
  ],
  cat: [
    {
      id: 1,
      name: 'Premium Cat Formula',
      description: 'Ideal for adult cats, balanced nutrition',
      rating: 4.8
    }
  ],
  hamster: [
    {
      id: 1,
      name: 'Hamster Complete Diet',
      description: 'Balanced mix with seeds and essential nutrients',
      rating: 4.6
    }
  ],
  parrot: [
    {
      id: 1, 
      name: 'Parrot Seed & Nut Mix',
      description: 'Complete balanced nutrition for healthy parrots',
      rating: 4.5
    }
  ]
};
