import { DERFactors, activityMultipliers, bcsAdjustmentFactors, PetType } from '@/data/nutrition-data';

/**
 * Calculate Daily Energy Requirements (DER) for pets
 * 
 * @param petType Type of pet ('dog', 'cat', 'hamster', 'parrot')
 * @param weightKg Weight in kilograms
 * @param lifeStage Life stage of the pet
 * @param bcsScore Body Condition Score (1-9)
 * @param activityLevel Activity level (low, normal, high)
 * @returns Calculated daily calorie requirements
 */
export const calculateDailyCalories = (
  petType: PetType,
  weightKg: number,
  lifeStage: string,
  bcsScore: number,
  activityLevel: 'low' | 'normal' | 'high' = 'normal'
): number => {
  if (weightKg <= 0) return 0;
  
  try {
    // Calculate Resting Energy Requirement (RER)
    // Standard formula: 70 * (bodyWeight in kg)^0.75
    const RER = 70 * Math.pow(weightKg, 0.75);
    
    // Get the DER factor based on pet type and life stage
    const derFactor = DERFactors[petType][lifeStage as keyof typeof DERFactors[typeof petType]] || 1.6;
    
    // Get activity level multiplier
    const activityMultiplier = activityMultipliers[activityLevel];
    
    // Get BCS adjustment factor
    const bcsAdjustment = bcsAdjustmentFactors[bcsScore as keyof typeof bcsAdjustmentFactors] || 1.0;
    
    // Calculate Daily Energy Requirement (DER)
    const DER = RER * derFactor * activityMultiplier * bcsAdjustment;
    
    // Round to nearest whole number
    return Math.round(DER);
  } catch (error) {
    console.error('Error calculating daily calories:', error);
    return 0;
  }
};
