import React, { createContext, useState, useContext, ReactNode } from 'react';

// 支持的语言类型
export type Language = 'en' | 'zh' | 'zh-TW';

// 语言上下文接口定义
interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

// 创建上下文
const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// 翻译字典
const translations: Record<Language, Record<string, string>> = {
  en: {
    // General
    'app.title': 'Pet Nutrition Calculator',
    'app.subtitle': 'Calculate your pet\'s daily nutrition needs with precision',
    'app.howItWorks': 'How It Works',
    'app.darkMode': 'Dark Mode',
    'app.lightMode': 'Light Mode',
    
    // Pet Info
    'petInfo.title': 'Pet Information',
    'petInfo.type': 'Pet Type',
    'petInfo.dog': 'Dog',
    'petInfo.cat': 'Cat',
    'petInfo.hamster': 'Hamster',
    'petInfo.parrot': 'Parrot',
    'petInfo.weight': 'Pet Weight',
    'petInfo.lifeStage': 'Life Stage',
    'petInfo.isNeutered': 'Neutered/Spayed?',
    'petInfo.yes': 'Yes',
    'petInfo.no': 'No',
    'petInfo.activityLevel': 'Activity Level',
    'petInfo.activityLevelTooltip': 'How active is your pet on a daily basis?',
    'petInfo.low': 'Low',
    'petInfo.normal': 'Normal',
    'petInfo.high': 'High',
    'petInfo.calculateButton': 'Calculate Nutrition',
    
    // Life stages - Dog
    'lifeStage.dog.puppy-under-4m': 'Puppy (under 4 months)',
    'lifeStage.dog.puppy-4-12m': 'Puppy (4-12 months)',
    'lifeStage.dog.adult-unneutered': 'Adult (unneutered)',
    'lifeStage.dog.adult-neutered': 'Adult (neutered)',
    'lifeStage.dog.senior': 'Senior',
    'lifeStage.dog.pregnant': 'Pregnant',
    'lifeStage.dog.lactating': 'Lactating',
    'lifeStage.dog.weight-loss': 'Weight Loss',
    
    // Life stages - Cat
    'lifeStage.cat.kitten': 'Kitten',
    'lifeStage.cat.adult-unneutered': 'Adult (unneutered)',
    'lifeStage.cat.adult-neutered': 'Adult (neutered)',
    'lifeStage.cat.senior': 'Senior',
    'lifeStage.cat.pregnant': 'Pregnant',
    'lifeStage.cat.lactating': 'Lactating',
    'lifeStage.cat.weight-loss': 'Weight Loss',
    
    // Life stages - Hamster
    'lifeStage.hamster.baby': 'Baby (under 2 months)',
    'lifeStage.hamster.young': 'Young (2-4 months)',
    'lifeStage.hamster.adult': 'Adult (4-12 months)',
    'lifeStage.hamster.senior': 'Senior (over 1 year)',
    
    // Life stages - Parrot
    'lifeStage.parrot.chick': 'Chick',
    'lifeStage.parrot.juvenile': 'Juvenile',
    'lifeStage.parrot.young-adult': 'Young Adult',
    'lifeStage.parrot.adult': 'Adult',
    'lifeStage.parrot.senior': 'Senior',
    
    // BCS
    'bcs.title': 'Body Condition Score (BCS)',
    'bcs.tooltip': 'BCS helps assess if your pet is at an ideal weight',
    'bcs.veryThin': 'Very Thin',
    'bcs.ideal': 'Ideal',
    'bcs.obese': 'Obese',
    'bcs.currentScore': 'Current Score',
    'bcs.chart': 'BCS Chart',
    
    // Results
    'results.title': 'Nutrition Results',
    'results.dailyCalories': 'Daily Caloric Needs',
    'results.kcalPerDay': 'kcal/day',
    'results.weightManagement': 'Weight Management',
    'results.weightLoss': 'Weight Loss',
    'results.maintenance': 'Maintenance',
    'results.weightGain': 'Weight Gain',
    'results.recommendedNutrition': 'Recommended Nutrition',
    'results.protein': 'Protein',
    'results.fat': 'Fat',
    'results.carbohydrate': 'Carbohydrate',
    'results.recommendedProducts': 'Recommended Products',
    'results.viewAll': 'View all recommendations',
    
    // How It Works
    'howItWorks.calculationMethod': 'Calculation Method',
    'howItWorks.calculationMethodDesc': 'We use the standard formula RER = 70 × (weight in kg)^0.75 to calculate your pet\'s Resting Energy Requirements. Then we adjust based on life stage, activity level, and body condition.',
    'howItWorks.bcsMethod': 'Body Condition Score',
    'howItWorks.bcsMethodDesc': 'The BCS is a 9-point scale used by veterinarians to assess whether your pet is underweight, ideal weight, or overweight. Adjusting this helps personalize the nutrition plan.',
    'howItWorks.nutritionGuidelines': 'Nutrition Guidelines',
    'howItWorks.nutritionGuidelinesDesc': 'Our recommendations follow AAFCO (Association of American Feed Control Officials) guidelines to ensure your pet receives the right balance of proteins, fats, and carbohydrates.',
    
    // Unit Conversion
    'unitConversion.title': 'Unit Conversion',
    'unitConversion.description': 'Convert between different units for pet nutrition calculations.',
    'unitConversion.weight': 'Weight',
    'unitConversion.energy': 'Energy',
    'unitConversion.volume': 'Volume',
    'unitConversion.value': 'Value',
    'unitConversion.from': 'From',
    'unitConversion.to': 'To',
    'unitConversion.selectUnit': 'Select unit',
    'unitConversion.convert': 'Convert',
    'unitConversion.reset': 'Reset',
    'unitConversion.close': 'Close',
    'unitConversion.invalidInput': 'Invalid input',
    'unitConversion.conversionTable': 'Conversion Table',
    'unitConversion.multiply': 'Multiply By',
    'unitConversion.energyInfo': 'Energy Units in Pet Nutrition',
    'unitConversion.energyDescription': 'Energy in pet food is commonly measured in kilocalories (kcal) or kilojoules (kJ). The daily energy requirement (DER) is typically expressed in kcal/day.',
    'unitConversion.volumeInfo': 'Volume Units in Pet Feeding',
    'unitConversion.volumeDescription': 'When measuring pet food, it\'s important to note that volume measurements can vary based on the density of the food. For accuracy, weight measurements are preferred.',
    
    // Units
    'unit.kilogram': 'kg',
    'unit.gram': 'g',
    'unit.pound': 'lb',
    'unit.ounce': 'oz',
    'unit.liter': 'l',
    'unit.milliliter': 'ml',
    'unit.cup': 'cup',
    'unit.tablespoon': 'tbsp',
    'unit.teaspoon': 'tsp',
    'unit.kcal': 'kcal',
    'unit.kJ': 'kJ',
  },
  zh: {
    // 通用
    'app.title': '宠物营养计算器',
    'app.subtitle': '精确计算您宠物的每日营养需求',
    'app.howItWorks': '工作原理',
    'app.darkMode': '深色模式',
    'app.lightMode': '浅色模式',
    
    // 宠物信息
    'petInfo.title': '宠物信息',
    'petInfo.type': '宠物类型',
    'petInfo.dog': '狗',
    'petInfo.cat': '猫',
    'petInfo.hamster': '仓鼠',
    'petInfo.parrot': '鹦鹉',
    'petInfo.weight': '宠物体重',
    'petInfo.lifeStage': '生命阶段',
    'petInfo.isNeutered': '是否绝育？',
    'petInfo.yes': '是',
    'petInfo.no': '否',
    'petInfo.activityLevel': '活动水平',
    'petInfo.activityLevelTooltip': '您的宠物每天活动量如何？',
    'petInfo.low': '低',
    'petInfo.normal': '正常',
    'petInfo.high': '高',
    'petInfo.calculateButton': '计算营养',
    
    // 生命阶段 - 狗
    'lifeStage.dog.puppy-under-4m': '幼犬（4个月以下）',
    'lifeStage.dog.puppy-4-12m': '幼犬（4-12个月）',
    'lifeStage.dog.adult-unneutered': '成年（未绝育）',
    'lifeStage.dog.adult-neutered': '成年（已绝育）',
    'lifeStage.dog.senior': '老年',
    'lifeStage.dog.pregnant': '怀孕期',
    'lifeStage.dog.lactating': '哺乳期',
    'lifeStage.dog.weight-loss': '减肥期',
    
    // 生命阶段 - 猫
    'lifeStage.cat.kitten': '幼猫',
    'lifeStage.cat.adult-unneutered': '成年（未绝育）',
    'lifeStage.cat.adult-neutered': '成年（已绝育）',
    'lifeStage.cat.senior': '老年',
    'lifeStage.cat.pregnant': '怀孕期',
    'lifeStage.cat.lactating': '哺乳期', 
    'lifeStage.cat.weight-loss': '减肥期',
    
    // 生命阶段 - 仓鼠
    'lifeStage.hamster.baby': '幼鼠（2个月以下）',
    'lifeStage.hamster.young': '青年（2-4个月）',
    'lifeStage.hamster.adult': '成年（4-12个月）',
    'lifeStage.hamster.senior': '老年（1年以上）',
    
    // 生命阶段 - 鹦鹉
    'lifeStage.parrot.chick': '雏鸟期',
    'lifeStage.parrot.juvenile': '少年期',
    'lifeStage.parrot.young-adult': '青年期',
    'lifeStage.parrot.adult': '成年期',
    'lifeStage.parrot.senior': '老年期',
    
    // 体况评分
    'bcs.title': '体况评分 (BCS)',
    'bcs.tooltip': 'BCS有助于评估您的宠物是否处于理想体重',
    'bcs.veryThin': '非常瘦',
    'bcs.underweight': '偏瘦',
    'bcs.ideal': '理想',
    'bcs.overweight': '超重',
    'bcs.obese': '肥胖',
    'bcs.currentScore': '当前评分',
    'bcs.chart': 'BCS图表',
    
    // 结果
    'results.title': '营养结果',
    'results.dailyCalories': '每日卡路里需求',
    'results.kcalPerDay': '千卡/天',
    'results.weightManagement': '体重管理',
    'results.weightLoss': '减肥',
    'results.maintenance': '维持',
    'results.weightGain': '增重',
    'results.recommendedNutrition': '推荐营养',
    'results.protein': '蛋白质',
    'results.fat': '脂肪',
    'results.carbohydrate': '碳水化合物',
    'results.recommendedProducts': '推荐产品',
    'results.viewAll': '查看所有推荐',
    
    // 工作原理
    'howItWorks.calculationMethod': '计算方法',
    'howItWorks.calculationMethodDesc': '我们使用标准公式 RER = 70 ×（体重公斤数）^0.75 来计算宠物的静息能量需求。然后根据生命阶段、活动水平和体况进行调整。',
    'howItWorks.bcsMethod': '体况评分',
    'howItWorks.bcsMethodDesc': 'BCS是兽医用来评估宠物是否体重不足、理想体重或超重的9分制量表。调整这个可以帮助个性化营养计划。',
    'howItWorks.nutritionGuidelines': '营养指南',
    'howItWorks.nutritionGuidelinesDesc': '我们的建议遵循AAFCO（美国饲料管理官员协会）指南，确保您的宠物获得蛋白质、脂肪和碳水化合物的适当平衡。',
    
    // 单位换算
    'unitConversion.title': '单位换算',
    'unitConversion.description': '为宠物营养计算在不同单位间进行换算。',
    'unitConversion.weight': '重量',
    'unitConversion.energy': '能量',
    'unitConversion.volume': '体积',
    'unitConversion.value': '数值',
    'unitConversion.from': '从',
    'unitConversion.to': '到',
    'unitConversion.selectUnit': '选择单位',
    'unitConversion.convert': '换算',
    'unitConversion.reset': '重置',
    'unitConversion.close': '关闭',
    'unitConversion.invalidInput': '无效输入',
    'unitConversion.conversionTable': '换算表',
    'unitConversion.multiply': '乘以',
    'unitConversion.energyInfo': '宠物营养学中的能量单位',
    'unitConversion.energyDescription': '宠物食品中的能量通常以千卡路里(kcal)或千焦耳(kJ)为单位。每日能量需求(DER)通常以kcal/天表示。',
    'unitConversion.volumeInfo': '宠物喂食中的体积单位',
    'unitConversion.volumeDescription': '在测量宠物食品时，需要注意体积测量可能因食品密度而异。为了精确，推荐使用重量测量。',
    
    // 单位
    'unit.kilogram': '千克',
    'unit.gram': '克',
    'unit.pound': '磅',
    'unit.ounce': '盎司',
    'unit.liter': '升',
    'unit.milliliter': '毫升',
    'unit.cup': '杯',
    'unit.tablespoon': '汤匙',
    'unit.teaspoon': '茶匙',
    'unit.kcal': '千卡',
    'unit.kJ': '千焦',
  },
  'zh-TW': {
    // 通用
    'app.title': '寵物營養計算器',
    'app.subtitle': '精確計算您寵物的每日營養需求',
    'app.howItWorks': '工作原理',
    'app.darkMode': '深色模式',
    'app.lightMode': '淺色模式',
    
    // 寵物資訊
    'petInfo.title': '寵物資訊',
    'petInfo.type': '寵物類型',
    'petInfo.dog': '狗',
    'petInfo.cat': '貓',
    'petInfo.hamster': '倉鼠',
    'petInfo.parrot': '鸚鵡',
    'petInfo.weight': '寵物體重',
    'petInfo.lifeStage': '生命階段',
    'petInfo.isNeutered': '是否絕育？',
    'petInfo.yes': '是',
    'petInfo.no': '否',
    'petInfo.activityLevel': '活動水平',
    'petInfo.activityLevelTooltip': '您的寵物每天活動量如何？',
    'petInfo.low': '低',
    'petInfo.normal': '正常',
    'petInfo.high': '高',
    'petInfo.calculateButton': '計算營養',
    
    // 生命階段 - 狗
    'lifeStage.dog.puppy-under-4m': '幼犬（4個月以下）',
    'lifeStage.dog.puppy-4-12m': '幼犬（4-12個月）',
    'lifeStage.dog.adult-unneutered': '成年（未絕育）',
    'lifeStage.dog.adult-neutered': '成年（已絕育）',
    'lifeStage.dog.senior': '老年',
    'lifeStage.dog.pregnant': '懷孕期',
    'lifeStage.dog.lactating': '哺乳期',
    'lifeStage.dog.weight-loss': '減重期',
    
    // 生命階段 - 貓
    'lifeStage.cat.kitten': '幼貓',
    'lifeStage.cat.adult-unneutered': '成年（未絕育）',
    'lifeStage.cat.adult-neutered': '成年（已絕育）',
    'lifeStage.cat.senior': '老年',
    'lifeStage.cat.pregnant': '懷孕期',
    'lifeStage.cat.lactating': '哺乳期', 
    'lifeStage.cat.weight-loss': '減重期',
    
    // 生命階段 - 倉鼠
    'lifeStage.hamster.baby': '幼鼠（2個月以下）',
    'lifeStage.hamster.young': '青年（2-4個月）',
    'lifeStage.hamster.adult': '成年（4-12個月）',
    'lifeStage.hamster.senior': '老年（1年以上）',
    
    // 生命階段 - 鸚鵡
    'lifeStage.parrot.chick': '雛鳥期',
    'lifeStage.parrot.juvenile': '少年期',
    'lifeStage.parrot.young-adult': '青年期',
    'lifeStage.parrot.adult': '成年期',
    'lifeStage.parrot.senior': '老年期',
    
    // 體況評分
    'bcs.title': '體況評分 (BCS)',
    'bcs.tooltip': 'BCS有助於評估您的寵物是否處於理想體重',
    'bcs.veryThin': '非常瘦',
    'bcs.underweight': '偏瘦',
    'bcs.ideal': '理想',
    'bcs.overweight': '超重',
    'bcs.obese': '肥胖',
    'bcs.currentScore': '當前評分',
    'bcs.chart': 'BCS圖表',
    
    // 結果
    'results.title': '營養結果',
    'results.dailyCalories': '每日卡路里需求',
    'results.kcalPerDay': '千卡/天',
    'results.weightManagement': '體重管理',
    'results.weightLoss': '減重',
    'results.maintenance': '維持',
    'results.weightGain': '增重',
    'results.recommendedNutrition': '推薦營養',
    'results.protein': '蛋白質',
    'results.fat': '脂肪',
    'results.carbohydrate': '碳水化合物',
    'results.recommendedProducts': '推薦產品',
    'results.viewAll': '查看所有推薦',
    
    // 工作原理
    'howItWorks.calculationMethod': '計算方法',
    'howItWorks.calculationMethodDesc': '我們使用標準公式 RER = 70 ×（體重公斤數）^0.75 來計算寵物的靜息能量需求。然後根據生命階段、活動水平和體況進行調整。',
    'howItWorks.bcsMethod': '體況評分',
    'howItWorks.bcsMethodDesc': 'BCS是獸醫用來評估寵物是否體重不足、理想體重或超重的9分制量表。調整這個可以幫助個性化營養計劃。',
    'howItWorks.nutritionGuidelines': '營養指南',
    'howItWorks.nutritionGuidelinesDesc': '我們的建議遵循AAFCO（美國飼料管理官員協會）指南，確保您的寵物獲得蛋白質、脂肪和碳水化合物的適當平衡。',
    
    // 單位換算
    'unitConversion.title': '單位換算',
    'unitConversion.description': '為寵物營養計算在不同單位間進行換算。',
    'unitConversion.weight': '重量',
    'unitConversion.energy': '能量',
    'unitConversion.volume': '體積',
    'unitConversion.value': '數值',
    'unitConversion.from': '從',
    'unitConversion.to': '到',
    'unitConversion.selectUnit': '選擇單位',
    'unitConversion.convert': '換算',
    'unitConversion.reset': '重置',
    'unitConversion.close': '關閉',
    'unitConversion.invalidInput': '無效輸入',
    'unitConversion.conversionTable': '換算表',
    'unitConversion.multiply': '乘以',
    'unitConversion.energyInfo': '寵物營養學中的能量單位',
    'unitConversion.energyDescription': '寵物食品中的能量通常以千卡路里(kcal)或千焦耳(kJ)為單位。每日能量需求(DER)通常以kcal/天表示。',
    'unitConversion.volumeInfo': '寵物餵食中的體積單位',
    'unitConversion.volumeDescription': '在測量寵物食品時，需要注意體積測量可能因食品密度而異。為了精確，推薦使用重量測量。',
    
    // 單位
    'unit.kilogram': '公斤',
    'unit.gram': '克',
    'unit.pound': '磅',
    'unit.ounce': '盎司',
    'unit.liter': '升',
    'unit.milliliter': '毫升',
    'unit.cup': '杯',
    'unit.tablespoon': '湯匙',
    'unit.teaspoon': '茶匙',
    'unit.kcal': '千卡',
    'unit.kJ': '千焦',
  }
};

// BCS 描述翻译
export const bcsDescriptionsTranslated = {
  en: {
    dog: {
      1: {
        title: 'Very Thin',
        description: 'Ribs, spine, and hip bones easily visible. No palpable fat. Obvious waist and abdominal tuck. Muscle loss present.'
      },
      3: {
        title: 'Underweight',
        description: 'Ribs easily palpable and may be visible. Top of lumbar vertebrae visible. Obvious waist and abdominal tuck.'
      },
      5: {
        title: 'Ideal',
        description: 'Ribs palpable without excess fat covering. Waist observed behind ribs when viewed from above. Abdomen tucked up when viewed from side.'
      },
      7: {
        title: 'Overweight',
        description: 'Ribs palpable with difficulty with moderate fat covering. Waist is discernible but not prominent. Abdominal tuck apparent.'
      },
      9: {
        title: 'Obese',
        description: 'Ribs not palpable under very heavy fat cover. Heavy fat deposits over lumbar spine and base of tail. No waist and abdominal distension present.'
      }
    },
    cat: {
      1: {
        title: 'Very Thin',
        description: 'Ribs visible on shorthaired cats; no palpable fat; severe abdominal tuck; lumbar vertebrae and wings of ilia easily palpated.'
      },
      3: {
        title: 'Underweight',
        description: 'Ribs easily palpable with minimal fat covering; lumbar vertebrae obvious; obvious waist behind ribs; minimal abdominal fat.'
      },
      5: {
        title: 'Ideal',
        description: 'Well-proportioned; waist observed behind ribs; ribs palpable with slight fat covering; abdominal fat pad minimal.'
      },
      7: {
        title: 'Overweight',
        description: 'Ribs not easily palpable with moderate fat covering; waist poorly discernible; obvious rounding of abdomen; moderate abdominal fat pad.'
      },
      9: {
        title: 'Obese',
        description: 'Ribs not palpable under heavy fat cover; heavy fat deposits over lumbar area, face and limbs; distended abdomen with no waist; extensive abdominal fat deposits.'
      }
    }
  },
  zh: {
    dog: {
      1: {
        title: '非常瘦',
        description: '肋骨、脊柱和髋骨容易看见。没有可触摸的脂肪。腰部明显收缩，腹部向上凹陷。有肌肉流失。'
      },
      3: {
        title: '体重不足',
        description: '肋骨容易摸到且可能可见。腰椎顶部可见。腰部明显收缩，腹部向上凹陷。'
      },
      5: {
        title: '理想体重',
        description: '能摸到肋骨但没有多余的脂肪覆盖。从上方看可见腰部收缩。从侧面看腹部向上收缩。'
      },
      7: {
        title: '超重',
        description: '肋骨摸起来有困难，有适度脂肪覆盖。腰部可辨别但不明显。腹部收缩可见。'
      },
      9: {
        title: '肥胖',
        description: '很厚的脂肪层下肋骨摸不到。腰椎和尾部基部有厚厚的脂肪堆积。没有腰部收缩且腹部膨胀。'
      }
    },
    cat: {
      1: {
        title: '非常瘦',
        description: '短毛猫可见肋骨；没有可触摸的脂肪；腹部严重收缩；腰椎和髂骨翼容易摸到。'
      },
      3: {
        title: '体重不足',
        description: '肋骨容易摸到，脂肪覆盖少；腰椎明显；肋骨后腰部明显收缩；腹部脂肪最少。'
      },
      5: {
        title: '理想体重',
        description: '比例良好；肋骨后可见腰部；肋骨可摸到且有轻微脂肪覆盖；腹部脂肪垫最少。'
      },
      7: {
        title: '超重',
        description: '肋骨不容易摸到，有适度脂肪覆盖；腰部不明显；腹部明显圆润；有适度腹部脂肪垫。'
      },
      9: {
        title: '肥胖',
        description: '厚重脂肪层下肋骨摸不到；腰部区域、面部和四肢有厚重脂肪堆积；腹部膨胀无腰部收缩；大量腹部脂肪堆积。'
      }
    }
  },
  'zh-TW': {
    dog: {
      1: {
        title: '非常瘦',
        description: '肋骨、脊柱和髖骨容易看見。沒有可觸摸的脂肪。腰部明顯收縮，腹部向上凹陷。有肌肉流失。'
      },
      3: {
        title: '體重不足',
        description: '肋骨容易摸到且可能可見。腰椎頂部可見。腰部明顯收縮，腹部向上凹陷。'
      },
      5: {
        title: '理想體重',
        description: '能摸到肋骨但沒有多餘的脂肪覆蓋。從上方看可見腰部收縮。從側面看腹部向上收縮。'
      },
      7: {
        title: '超重',
        description: '肋骨摸起來有困難，有適度脂肪覆蓋。腰部可辨別但不明顯。腹部收縮可見。'
      },
      9: {
        title: '肥胖',
        description: '很厚的脂肪層下肋骨摸不到。腰椎和尾部基部有厚厚的脂肪堆積。沒有腰部收縮且腹部膨脹。'
      }
    },
    cat: {
      1: {
        title: '非常瘦',
        description: '短毛貓可見肋骨；沒有可觸摸的脂肪；腹部嚴重收縮；腰椎和髂骨翼容易摸到。'
      },
      3: {
        title: '體重不足',
        description: '肋骨容易摸到，脂肪覆蓋少；腰椎明顯；肋骨後腰部明顯收縮；腹部脂肪最少。'
      },
      5: {
        title: '理想體重',
        description: '比例良好；肋骨後可見腰部；肋骨可摸到且有輕微脂肪覆蓋；腹部脂肪墊最少。'
      },
      7: {
        title: '超重',
        description: '肋骨不容易摸到，有適度脂肪覆蓋；腰部不明顯；腹部明顯圓潤；有適度腹部脂肪墊。'
      },
      9: {
        title: '肥胖',
        description: '厚重脂肪層下肋骨摸不到；腰部區域、面部和四肢有厚重脂肪堆積；腹部膨脹無腰部收縮；大量腹部脂肪堆積。'
      }
    }
  }
};

// 语言提供者组件
export const LanguageProvider: React.FC<{children: ReactNode}> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');
  
  // 翻译函数
  const t = (key: string): string => {
    return translations[language][key] || key;
  };
  
  const contextValue: LanguageContextType = {
    language,
    setLanguage,
    t
  };
  
  return (
    <LanguageContext.Provider value={contextValue}>
      {children}
    </LanguageContext.Provider>
  );
};

// 使用语言上下文的hook
export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};