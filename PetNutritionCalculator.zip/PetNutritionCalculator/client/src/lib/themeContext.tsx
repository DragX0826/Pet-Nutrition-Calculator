import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';

// 主题模式类型
export type ThemeMode = 'light' | 'dark';

// 主题上下文接口定义
interface ThemeContextType {
  theme: ThemeMode;
  setTheme: (mode: ThemeMode) => void;
  toggleTheme: () => void;
}

// 创建主题上下文
const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

// 主题提供者组件
export const ThemeProvider: React.FC<{children: ReactNode}> = ({ children }) => {
  // 从本地存储获取主题设置或使用默认的浅色主题
  const [theme, setTheme] = useState<ThemeMode>(() => {
    const savedTheme = localStorage.getItem('theme');
    return (savedTheme as ThemeMode) || 'light';
  });
  
  // 切换主题函数
  const toggleTheme = () => {
    setTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));
  };
  
  // 当主题变化时，应用相应的类到 document 元素
  useEffect(() => {
    // 保存主题设置到本地存储
    localStorage.setItem('theme', theme);
    
    // 更新 document 的类
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);
  
  const contextValue: ThemeContextType = {
    theme,
    setTheme,
    toggleTheme
  };
  
  return (
    <ThemeContext.Provider value={contextValue}>
      {children}
    </ThemeContext.Provider>
  );
};

// 使用主题上下文的钩子
export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};