import React from 'react';
import InputForm from './InputForm';
import BodyConditionScoreSelector from './BodyConditionScoreSelector';
import ResultsAndRecommendations from './ResultsAndRecommendations';
import UnitConversionHelper from './UnitConversionHelper';
import { useState, useEffect } from 'react';
import { PawPrint } from 'lucide-react';
import { calculateDailyCalories } from '@/lib/calculationUtils';
import { useLanguage } from '@/lib/languageContext';
import { useTheme } from '@/lib/themeContext';
import { PetType } from '@/data/nutrition-data';

const PetNutritionCalculator = () => {
  const { t } = useLanguage();
  const { theme } = useTheme();
  const [petType, setPetType] = useState<PetType>('dog');
  const [petWeight, setPetWeight] = useState<number | ''>('');
  const [weightUnit, setWeightUnit] = useState<'kg' | 'lb'>('kg');
  const [lifeStage, setLifeStage] = useState('adult-neutered');
  const [bcsScore, setBcsScore] = useState(5);
  const [activityLevel, setActivityLevel] = useState<'low' | 'normal' | 'high'>('normal');
  const [dailyCalories, setDailyCalories] = useState(0);
  const [isNeutered, setIsNeutered] = useState(true);
  
  // Calculate daily calories
  useEffect(() => {
    if (petWeight !== '') {
      // Convert weight to kg if in lb
      const weightInKg = weightUnit === 'lb' ? Number(petWeight) * 0.453592 : Number(petWeight);
      
      const calories = calculateDailyCalories(
        petType, 
        weightInKg, 
        lifeStage, 
        bcsScore, 
        activityLevel
      );
      
      setDailyCalories(calories);
    } else {
      setDailyCalories(0);
    }
  }, [petType, petWeight, weightUnit, lifeStage, bcsScore, activityLevel]);

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <header className="mb-8 text-center">
        <h1 className="text-3xl font-bold text-primary flex items-center justify-center">
          <PawPrint className="mr-2" /> {t('app.title')}
        </h1>
        <p className="text-muted-foreground mt-2">{t('app.subtitle')}</p>
        
        <div className="mt-4 flex justify-center">
          <UnitConversionHelper />
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Input Form */}
        <InputForm 
          petType={petType}
          setPetType={setPetType}
          petWeight={petWeight}
          setPetWeight={setPetWeight}
          weightUnit={weightUnit}
          setWeightUnit={setWeightUnit}
          lifeStage={lifeStage}
          setLifeStage={setLifeStage}
          activityLevel={activityLevel}
          setActivityLevel={setActivityLevel}
          isNeutered={isNeutered}
          setIsNeutered={setIsNeutered}
        />

        {/* Middle Column: Body Condition Score */}
        <BodyConditionScoreSelector 
          petType={petType}
          bcsScore={bcsScore}
          setBcsScore={setBcsScore}
        />

        {/* Right Column: Results & Recommendations */}
        <ResultsAndRecommendations 
          petType={petType}
          dailyCalories={dailyCalories}
          bcsScore={bcsScore}
        />
      </div>
      
      {/* Additional Information Section */}
      <div className={`mt-8 ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} rounded-xl shadow-md p-6`}>
        <h2 className="text-lg font-semibold mb-4 text-primary">{t('app.howItWorks')}</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div>
            <h3 className="font-medium text-foreground mb-2 flex items-center">
              <CalculatorIcon className="text-primary mr-2" /> {t('howItWorks.calculationMethod')}
            </h3>
            <p className="text-sm text-muted-foreground">
              {t('howItWorks.calculationMethodDesc')}
            </p>
          </div>
          <div>
            <h3 className="font-medium text-foreground mb-2 flex items-center">
              <BodyScanIcon className="text-primary mr-2" /> {t('howItWorks.bcsMethod')}
            </h3>
            <p className="text-sm text-muted-foreground">
              {t('howItWorks.bcsMethodDesc')}
            </p>
          </div>
          <div>
            <h3 className="font-medium text-foreground mb-2 flex items-center">
              <HeartPulseIcon className="text-primary mr-2" /> {t('howItWorks.nutritionGuidelines')}
            </h3>
            <p className="text-sm text-muted-foreground">
              {t('howItWorks.nutritionGuidelinesDesc')}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Custom icons for the How It Works section
const CalculatorIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className} width="16" height="16">
    <rect x="4" y="2" width="16" height="20" rx="2" />
    <line x1="8" x2="16" y1="6" y2="6" />
    <line x1="8" x2="16" y1="10" y2="10" />
    <line x1="8" x2="12" y1="14" y2="14" />
    <line x1="8" x2="12" y1="18" y2="18" />
  </svg>
);

const BodyScanIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className} width="16" height="16">
    <path d="M12 3a2 2 0 0 0-2 2v5h4V5a2 2 0 0 0-2-2z" />
    <path d="M10 10v7a2 2 0 0 0 4 0v-7" />
    <circle cx="12" cy="15" r="1" />
    <path d="M6 12a6 6 0 0 0 12 0" />
  </svg>
);

const HeartPulseIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className} width="16" height="16">
    <path d="M3 12h2l3 8 3-16 3 8h10" />
    <path d="M19 20a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" />
  </svg>
);

export default PetNutritionCalculator;
