import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Info } from 'lucide-react';
import { bcsDescriptions, PetType } from '@/data/nutrition-data';
import { useLanguage, bcsDescriptionsTranslated } from '@/lib/languageContext';
import { useTheme } from '@/lib/themeContext';

interface BodyConditionScoreSelectorProps {
  petType: PetType;
  bcsScore: number;
  setBcsScore: (score: number) => void;
}

const BodyConditionScoreSelector = ({
  petType,
  bcsScore,
  setBcsScore
}: BodyConditionScoreSelectorProps) => {
  const { t, language } = useLanguage();
  
  const handleSliderChange = (value: number[]) => {
    setBcsScore(value[0]);
  };

  const getBcsDescription = (score: number) => {
    // Map scores to nearest defined BCS score (1, 3, 5, 7, 9)
    const scoreKeys = [1, 3, 5, 7, 9] as const;
    type BcsKey = typeof scoreKeys[number];
    
    // Find the closest key
    const closest = scoreKeys.reduce((prev, curr) => 
      Math.abs(curr - score) < Math.abs(prev - score) ? curr : prev
    );
    
    // Default descriptions for pet types that don't have specific BCS descriptions
    const defaultDescription = (key: number) => {
      const descriptions: Record<number, { title: string; description: string }> = {
        1: { 
          title: t('bcs.veryThin'), 
          description: t('bcs.veryThin')
        },
        3: { 
          title: t('bcs.underweight'), 
          description: t('bcs.underweight')
        },
        5: { 
          title: t('bcs.ideal'), 
          description: t('bcs.ideal')
        },
        7: { 
          title: t('bcs.overweight'), 
          description: t('bcs.overweight')
        },
        9: { 
          title: t('bcs.obese'), 
          description: t('bcs.obese')
        }
      };
      return descriptions[key] || descriptions[5]; // Default to ideal if something goes wrong
    };
    
    // Use translated BCS descriptions based on current language and pet type
    try {
      // For dogs and cats, use the existing descriptions
      if ((petType === 'dog' || petType === 'cat') && language === 'en') {
        return bcsDescriptions[petType][closest as BcsKey];
      } else if (petType === 'dog' || petType === 'cat') {
        return bcsDescriptionsTranslated[language][petType][closest as BcsKey];
      } else {
        // For hamsters and parrots, use default descriptions
        return defaultDescription(closest);
      }
    } catch (error) {
      // Fallback to default descriptions if there's an error
      return defaultDescription(closest);
    }
  };

  // BCS scores for display
  const bcsScores = [1, 3, 5, 7, 9];

  return (
    <div className="lg:col-span-1">
      <Card className="pet-card p-6 h-full">
        <div className="flex items-center mb-6">
          <h2 className="text-lg font-semibold text-primary-700 flex items-center">
            <BodyScanIcon className="mr-2" /> {t('bcs.title')}
          </h2>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" className="p-0 h-auto ml-2">
                  <Info className="h-4 w-4 text-primary-500" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-sm">{t('bcs.tooltip')}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        
        {/* BCS Slider */}
        <div className="mb-6">
          <div className="flex justify-between mb-2">
            <span className="text-sm">{t('bcs.veryThin')}</span>
            <span className="text-sm">{t('bcs.underweight')}</span>
            <span className="text-sm">{t('bcs.ideal')}</span>
            <span className="text-sm">{t('bcs.overweight')}</span>
            <span className="text-sm">{t('bcs.obese')}</span>
          </div>
          <Slider 
            value={[bcsScore]} 
            min={1} 
            max={9} 
            step={1} 
            onValueChange={handleSliderChange}
            className="w-full"
          />
        </div>
        
        {/* BCS Visualizer */}
        <div className="grid grid-cols-5 gap-2 mb-6">
          {bcsScores.map((score) => (
            <div 
              key={score}
              className={`bcs-item border rounded-lg p-2 text-center cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-all relative ${
                bcsScore === score ? 'border-primary-500 bg-primary-50 dark:bg-primary-900 dark:text-white' : 'dark:text-gray-300'
              }`}
              onClick={() => setBcsScore(score)}
            >
              <div className="text-lg font-semibold">{score}</div>
              {bcsScore === score && (
                <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-8 border-r-8 border-b-8 border-l-transparent border-r-transparent border-b-primary-500"></div>
              )}
            </div>
          ))}
        </div>
        
        {/* Current BCS Details */}
        <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 mb-6">
          <h3 className="font-medium text-primary mb-2">
            {t('bcs.currentScore')}: <span id="current-bcs">{bcsScore} - {getBcsDescription(bcsScore).title}</span>
          </h3>
          <p className="text-sm text-gray-600 dark:text-gray-300">
            {getBcsDescription(bcsScore).description}
          </p>
        </div>
        
        {/* BCS Image - Using SVG instead of external images */}
        <div className="mt-4 relative">
          <div className="bcs-chart-container w-full h-64 flex items-center justify-center overflow-hidden">
            <BcsDiagram petType={petType} bcsScore={bcsScore} />
          </div>
          <div className="absolute bottom-3 right-3 bg-primary text-white text-xs py-1 px-2 rounded">
            <PawIcon className="inline mr-1" /> {t(`petInfo.${petType}`) || petType} {t('bcs.chart')}
          </div>
        </div>
      </Card>
    </div>
  );
};

// Custom body scan icon
const BodyScanIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className} width="20" height="20">
    <path d="M12 3a2 2 0 0 0-2 2v5h4V5a2 2 0 0 0-2-2z" />
    <path d="M10 10v7a2 2 0 0 0 4 0v-7" />
    <circle cx="12" cy="15" r="1" />
    <path d="M6 12a6 6 0 0 0 12 0" />
  </svg>
);

// Custom paw icon
const PawIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className} width="12" height="12">
    <path d="M12.72 3.44c-.78-.59-1.92-.59-2.71 0-1.97 1.55-5.01 4.27-7.03 7.92-.83 1.5-.42 3.35.97 4.3 1.59 1.09 3.34 1.89 5.06 2.34 1.47.39 3.01.39 4.48 0 1.72-.45 3.47-1.25 5.06-2.34 1.39-.95 1.8-2.8.97-4.3-2.02-3.65-5.06-6.37-7.03-7.92Z" />
    <path d="M8 14.5c.5 2.5-.17 4.5-1 6.5-.4.97-1.75 1-2.5-.5-1-2-1-5.5.5-7.5.58-.77 1.5-.5 2 .5.5 1 .5 2 1 3.5" />
    <path d="M14.5 17.5c1 2.5 2 4.5 3.5 6 .67.67 1.7.32 2-.5.5-1.5.5-4 0-6.5-.33-1.67-2-1.5-3 0-1 1-2 1-2.5 1" />
  </svg>
);

// BCS Diagram SVG component
const BcsDiagram = ({ petType, bcsScore }: { petType: PetType, bcsScore: number }) => {
  const { t } = useLanguage();
  const { theme } = useTheme();
  const isDarkMode = theme === 'dark';
  const fillColor = isDarkMode ? '#1f2937' : '#f9f9f9';
  const strokeColor = '#3676E8';
  
  // Simplified visualization of different body condition scores
  const getShapePath = () => {
    // Different shape paths based on pet type and BCS score
    if (petType === 'hamster') {
      if (bcsScore <= 3) {
        // Thin hamster shape
        return "M60,40 C80,35 120,35 140,40 C150,45 150,55 140,60 C120,65 80,65 60,60 C50,55 50,45 60,40 Z";
      } else if (bcsScore <= 6) {
        // Ideal hamster shape (more rounded)
        return "M55,35 C80,30 120,30 145,35 C155,45 155,55 145,65 C120,70 80,70 55,65 C45,55 45,45 55,35 Z";
      } else {
        // Overweight hamster shape (very round)
        return "M50,30 C80,25 120,25 150,30 C160,45 160,55 150,70 C120,75 80,75 50,70 C40,55 40,45 50,30 Z";
      }
    } else if (petType === 'parrot') {
      if (bcsScore <= 3) {
        // Thin parrot body
        return "M70,30 C90,25 110,25 130,30 C140,40 140,60 130,70 C110,75 90,75 70,70 C60,60 60,40 70,30 Z";
      } else if (bcsScore <= 6) {
        // Ideal parrot body
        return "M65,25 C90,20 110,20 135,25 C145,40 145,60 135,75 C110,80 90,80 65,75 C55,60 55,40 65,25 Z";
      } else {
        // Overweight parrot body
        return "M60,20 C90,15 110,15 140,20 C150,40 150,60 140,80 C110,85 90,85 60,80 C50,60 50,40 60,20 Z";
      }
    } else if (petType === 'dog') {
      if (bcsScore <= 3) {
        // Thin dog shape with more pronounced rib cage
        return "M50,30 C70,25 130,25 150,30 C170,40 170,60 150,70 C130,75 70,75 50,70 C30,60 30,40 50,30 Z";
      } else if (bcsScore <= 6) {
        // Ideal dog shape with balanced proportions
        return "M40,25 C65,15 135,15 160,25 C180,40 180,60 160,75 C135,85 65,85 40,75 C20,60 20,40 40,25 Z";
      } else {
        // Overweight dog shape with rounded body
        return "M30,20 C60,5 140,5 170,20 C190,40 190,60 170,80 C140,95 60,95 30,80 C10,60 10,40 30,20 Z";
      }
    } else { // cat as default
      if (bcsScore <= 3) {
        // Thin cat shape 
        return "M50,30 C65,25 135,25 150,30 C165,35 165,65 150,70 C135,75 65,75 50,70 C35,65 35,35 50,30 Z";
      } else if (bcsScore <= 6) {
        // Ideal cat shape
        return "M45,25 C65,15 135,15 155,25 C170,40 170,60 155,75 C135,85 65,85 45,75 C30,60 30,40 45,25 Z";
      } else {
        // Overweight cat shape
        return "M35,20 C60,5 140,5 165,20 C180,40 180,60 165,80 C140,95 60,95 35,80 C20,60 20,40 35,20 Z";
      }
    }
  };
  
  // Add ribs for thin animals
  const getRibsPath = () => {
    if (bcsScore <= 3) {
      // Only show ribs for thin animals
      const baseX = petType === 'dog' ? 60 : 65;
      const ribSpacing = 12;
      const ribCount = 5;
      let paths = [];
      
      for (let i = 0; i < ribCount; i++) {
        const x = baseX + (i * ribSpacing);
        paths.push(`M${x},30 Q${x+5},50 ${x},70`);
      }
      
      return paths;
    }
    return [];
  };

  return (
    <svg width="100%" height="100%" viewBox="0 0 200 100" xmlns="http://www.w3.org/2000/svg">
      {/* Body outline */}
      <path 
        d={getShapePath()} 
        fill={fillColor} 
        stroke={strokeColor} 
        strokeWidth="2"
      />
      
      {/* Ribs for thin animals */}
      {getRibsPath().map((path, index) => (
        <path 
          key={index}
          d={path}
          fill="none"
          stroke={strokeColor}
          strokeWidth="1"
          strokeDasharray="2,2"
          opacity="0.5"
        />
      ))}
      
      {/* Head - different for each pet type */}
      {petType === 'hamster' ? (
        // Hamster head (smaller and rounder)
        <circle 
          cx="40" 
          cy="40" 
          r="10" 
          fill={fillColor} 
          stroke={strokeColor} 
          strokeWidth="2"
        />
      ) : petType === 'parrot' ? (
        // Parrot head with beak
        <g>
          <circle 
            cx="50" 
            cy="35" 
            r="12" 
            fill={fillColor} 
            stroke={strokeColor} 
            strokeWidth="2"
          />
          <path 
            d="M45,40 L35,45 L45,42" 
            fill={fillColor} 
            stroke={strokeColor} 
            strokeWidth="2"
            strokeLinecap="round"
          />
        </g>
      ) : (
        // Dog or cat head (default)
        <circle 
          cx={petType === 'dog' ? "30" : "35"} 
          cy="40" 
          r="15" 
          fill={fillColor} 
          stroke={strokeColor} 
          strokeWidth="2"
        />
      )}
      
      {/* Eyes - adjust position based on pet type */}
      {petType === 'hamster' ? (
        // Hamster eyes (closer together)
        <g>
          <circle cx="37" cy="37" r="1.5" fill={strokeColor} />
          <circle cx="43" cy="37" r="1.5" fill={strokeColor} />
        </g>
      ) : petType === 'parrot' ? (
        // Parrot eyes (on sides of head)
        <g>
          <circle cx="47" cy="32" r="2" fill={strokeColor} />
          <circle cx="53" cy="32" r="2" fill={strokeColor} />
        </g>
      ) : (
        // Dog or cat eyes (default)
        <g>
          <circle cx={petType === 'dog' ? "25" : "30"} cy="36" r="2" fill={strokeColor} />
          <circle cx={petType === 'dog' ? "35" : "40"} cy="36" r="2" fill={strokeColor} />
        </g>
      )}
      
      {/* Nose/beak - adjust for pet type */}
      {petType === 'hamster' ? (
        <circle cx="40" cy="42" r="2" fill={strokeColor} />
      ) : petType === 'parrot' ? (
        null  // Beak already defined in the head section
      ) : (
        <circle cx={petType === 'dog' ? "30" : "35"} cy="45" r="3" fill={strokeColor} />
      )}
      
      {/* Tail - different for each pet type */}
      {petType === 'hamster' ? (
        <path 
          d="M140,45 C150,45 155,50 155,55" 
          fill="none" 
          stroke={strokeColor} 
          strokeWidth="2" 
          strokeLinecap="round"
        />
      ) : petType === 'parrot' ? (
        <path 
          d="M135,50 C145,65 150,70 150,85" 
          fill="none" 
          stroke={strokeColor} 
          strokeWidth="2" 
          strokeLinecap="round"
        />
      ) : (
        <path 
          d={petType === 'dog' 
            ? "M160,50 C180,45 190,55 195,65" 
            : "M155,50 C170,30 175,25 180,20"}
          fill="none" 
          stroke={strokeColor} 
          strokeWidth="2" 
          strokeLinecap="round"
        />
      )}
      
      {/* Features specific to each pet type */}
      {petType === 'parrot' && (
        <g>
          {/* Wings */}
          <path 
            d="M90,30 C85,15 95,10 105,15 C115,20 110,35 100,40" 
            fill="none" 
            stroke={strokeColor} 
            strokeWidth="2" 
            strokeLinecap="round"
          />
          {/* Feet */}
          <path 
            d="M95,80 L95,90 M110,80 L110,90" 
            stroke={strokeColor} 
            strokeWidth="2" 
            strokeLinecap="round"
          />
        </g>
      )}
      
      {/* Legs (simplified) - adjust for each pet type */}
      {petType === 'hamster' ? (
        <g>
          <line x1="70" y1="65" x2="70" y2="75" stroke={strokeColor} strokeWidth="1.5" strokeLinecap="round" />
          <line x1="130" y1="65" x2="130" y2="75" stroke={strokeColor} strokeWidth="1.5" strokeLinecap="round" />
          <line x1="80" y1="65" x2="80" y2="75" stroke={strokeColor} strokeWidth="1.5" strokeLinecap="round" />
          <line x1="120" y1="65" x2="120" y2="75" stroke={strokeColor} strokeWidth="1.5" strokeLinecap="round" />
        </g>
      ) : petType === 'parrot' ? (
        null // Feet already defined above
      ) : (
        <g>
          <line x1="60" y1="75" x2="60" y2="90" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />
          <line x1="140" y1="75" x2="140" y2="90" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />
        </g>
      )}
      
      {/* Annotation */}
      <text x="100" y="50" textAnchor="middle" fill={strokeColor} fontWeight="bold" fontSize="10">
        BCS {bcsScore}
      </text>
    </svg>
  );
};

export default BodyConditionScoreSelector;
