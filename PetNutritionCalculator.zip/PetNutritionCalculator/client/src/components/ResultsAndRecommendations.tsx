import React from 'react';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Heart, PieChart, Scale } from 'lucide-react';
import { getNutritionRecommendations, PetType } from '@/data/nutrition-data';
import { useLanguage } from '@/lib/languageContext';

interface ResultsAndRecommendationsProps {
  petType: PetType;
  dailyCalories: number;
  bcsScore: number;
}

const ResultsAndRecommendations = ({
  petType,
  dailyCalories,
  bcsScore
}: ResultsAndRecommendationsProps) => {
  const { t } = useLanguage();
  
  // Calculate weight management calories
  const weightLossCalories = Math.round(dailyCalories * 0.8);
  const maintenanceCalories = dailyCalories;
  const weightGainCalories = Math.round(dailyCalories * 1.2);

  // Get nutrition recommendations based on pet type
  const nutritionRecommendations = getNutritionRecommendations(petType);
  
  // Calculate progress percentages for visualization
  const getProgressPercentage = (nutrient: { min: number, max: number }) => {
    return ((nutrient.min + nutrient.max) / 2) / 100 * 100;
  };

  return (
    <div className="lg:col-span-1">
      <Card className="shadow-md p-6">
        <h2 className="text-lg font-semibold mb-6 text-primary-700 dark:text-primary-400 flex items-center">
          <Heart className="mr-2" /> {t('results.title')}
        </h2>
        
        {/* Caloric Needs */}
        <div className="mb-6 text-center py-4 bg-primary-50 dark:bg-primary-900/30 rounded-lg">
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">{t('results.dailyCalories')}</h3>
          <div className="text-4xl font-bold text-primary-600 dark:text-primary-400">
            {dailyCalories.toLocaleString()}
          </div>
          <div className="text-sm text-gray-500 dark:text-gray-400">{t('results.kcalPerDay')}</div>
        </div>
        
        {/* Adjustments Based on BCS */}
        <div className="mb-6 bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
          <h3 className="font-medium text-primary-700 dark:text-primary-400 mb-2 flex items-center">
            <Scale className="mr-2" /> {t('results.weightManagement')}
          </h3>
          <div className="grid grid-cols-3 gap-2 mb-3">
            <div className="text-center p-2 bg-warning-50 dark:bg-warning-900/30 rounded border border-warning-500">
              <div className="text-sm font-medium text-warning-600 dark:text-warning-400 truncate">{t('results.weightLoss')}</div>
              <div className="text-lg font-semibold text-warning-600 dark:text-warning-400">
                {weightLossCalories.toLocaleString()}
              </div>
              <div className="text-xs text-warning-600 dark:text-warning-400">{t('results.kcalPerDay')}</div>
            </div>
            <div className="text-center p-2 bg-primary-50 dark:bg-primary-900/30 rounded border border-primary-500">
              <div className="text-sm font-medium text-primary-600 dark:text-primary-400 truncate">{t('results.maintenance')}</div>
              <div className="text-lg font-semibold text-primary-600 dark:text-primary-400">
                {maintenanceCalories.toLocaleString()}
              </div>
              <div className="text-xs text-primary-600 dark:text-primary-400">{t('results.kcalPerDay')}</div>
            </div>
            <div className="text-center p-2 bg-success-50 dark:bg-success-900/30 rounded border border-success-500">
              <div className="text-sm font-medium text-success-600 dark:text-success-400 truncate">{t('results.weightGain')}</div>
              <div className="text-lg font-semibold text-success-600 dark:text-success-400">
                {weightGainCalories.toLocaleString()}
              </div>
              <div className="text-xs text-success-600 dark:text-success-400">{t('results.kcalPerDay')}</div>
            </div>
          </div>
        </div>
        
        {/* Nutritional Breakdown */}
        <div>
          <h3 className="font-medium text-primary-700 dark:text-primary-400 mb-3 flex items-center">
            <PieChart className="mr-2" /> {t('results.recommendedNutrition')}
          </h3>
          <div className="space-y-3">
            {Object.entries(nutritionRecommendations).map(([nutrient, range]) => (
              <div key={nutrient}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium capitalize">{t(`results.${nutrient}`)}</span>
                  <span className="text-sm text-gray-600 dark:text-gray-400">{range.min}-{range.max}%</span>
                </div>
                <Progress 
                  value={getProgressPercentage(range)} 
                  className={`h-2 ${
                    nutrient === 'protein' ? 'bg-gray-100 dark:bg-gray-700' : 
                    nutrient === 'fat' ? 'bg-gray-100 dark:bg-gray-700' : 'bg-gray-100 dark:bg-gray-700'
                  }`}
                  // Set the color of the indicator through a style override
                  style={{
                    "--progress-foreground": nutrient === 'protein' ? 'var(--primary-500)' : 
                                           nutrient === 'fat' ? 'var(--warning-500)' : 'var(--success-500)'
                  } as React.CSSProperties}
                />
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
};



export default ResultsAndRecommendations;
