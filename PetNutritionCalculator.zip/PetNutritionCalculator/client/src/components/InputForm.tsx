import React from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Switch } from '@/components/ui/switch';
import { PawPrint, Cat, Bird, Info } from 'lucide-react';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { dogLifeStages, catLifeStages, hamsterLifeStages, parrotLifeStages, PetType } from '@/data/nutrition-data';
import { useLanguage } from '@/lib/languageContext';
import { useTheme } from '@/lib/themeContext';

// 自定义仓鼠图标
const HamsterIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className} width="16" height="16">
    <circle cx="12" cy="12" r="6" />
    <path d="M9 10a1 1 0 0 0 0 2" />
    <path d="M15 10a1 1 0 0 1 0 2" />
    <path d="M8 14c.5 1 2 2 4 2s3.5-1 4-2" />
    <path d="M18 12.5v-1" />
    <path d="M6 12.5v-1" />
    <path d="M12 18.5v-1" />
    <path d="M12 6.5v-1" />
  </svg>
);

interface InputFormProps {
  petType: PetType;
  setPetType: (type: PetType) => void;
  petWeight: number | '';
  setPetWeight: (weight: number | '') => void;
  weightUnit: 'kg' | 'lb';
  setWeightUnit: (unit: 'kg' | 'lb') => void;
  lifeStage: string;
  setLifeStage: (stage: string) => void;
  activityLevel: 'low' | 'normal' | 'high';
  setActivityLevel: (level: 'low' | 'normal' | 'high') => void;
  isNeutered: boolean;
  setIsNeutered: (neutered: boolean) => void;
}

const InputForm = ({
  petType,
  setPetType,
  petWeight,
  setPetWeight,
  weightUnit,
  setWeightUnit,
  lifeStage,
  setLifeStage,
  activityLevel,
  setActivityLevel,
  isNeutered,
  setIsNeutered
}: InputFormProps) => {
  const { t } = useLanguage();
  
  const handleWeightChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (value === '') {
      setPetWeight('');
    } else {
      const numValue = parseFloat(value);
      if (!isNaN(numValue) && numValue > 0) {
        setPetWeight(numValue);
      }
    }
  };

  const handleToggleUnit = () => {
    if (weightUnit === 'kg') {
      setWeightUnit('lb');
      // Convert kg to lb if a weight is entered
      if (petWeight !== '') {
        setPetWeight(parseFloat((petWeight * 2.20462).toFixed(1)));
      }
    } else {
      setWeightUnit('kg');
      // Convert lb to kg if a weight is entered
      if (petWeight !== '') {
        setPetWeight(parseFloat((petWeight / 2.20462).toFixed(1)));
      }
    }
  };

  const handleCalculate = () => {
    // Calculations are handled in the parent component via useEffect
    // This button is mostly for UX purposes
  };

  // Update life stage if needed when changing pet type
  React.useEffect(() => {
    // Set default life stage when switching pet type
    if (petType === 'dog') {
      setLifeStage('adult-neutered');
    } else if (petType === 'cat') {
      setLifeStage('adult-neutered');
    } else if (petType === 'hamster') {
      setLifeStage('adult');
    } else if (petType === 'parrot') {
      setLifeStage('adult');
    }
  }, [petType, setLifeStage]);

  // Get appropriate life stage options based on pet type
  const getLifeStageOptions = () => {
    switch (petType) {
      case 'dog':
        return dogLifeStages;
      case 'cat':
        return catLifeStages;
      case 'hamster':
        return hamsterLifeStages;
      case 'parrot':
        return parrotLifeStages;
      default:
        return dogLifeStages;
    }
  };
  
  const lifeStageOptions = getLifeStageOptions();

  return (
    <div className="lg:col-span-1">
      <Card className="pet-card p-6">
        <h2 className="text-lg font-semibold mb-6 text-primary flex items-center">
          <Info className="mr-2 h-5 w-5" /> {t('petInfo.title')}
        </h2>
        
        {/* Pet Type Selection */}
        <div className="mb-6">
          <Label className="block text-sm font-medium mb-2">{t('petInfo.type')}</Label>
          <div className="grid grid-cols-2 gap-3 mb-2">
            <Button
              type="button"
              variant={petType === 'dog' ? 'default' : 'outline'}
              className={`flex items-center justify-center py-2 px-3 ${
                petType === 'dog' ? 'bg-primary/10 text-primary border-primary' : 'hover:bg-primary/5'
              }`}
              onClick={() => setPetType('dog')}
            >
              <PawPrint className="mr-2 h-4 w-4" />
              <span>{t('petInfo.dog')}</span>
            </Button>
            <Button
              type="button"
              variant={petType === 'cat' ? 'default' : 'outline'}
              className={`flex items-center justify-center py-2 px-3 ${
                petType === 'cat' ? 'bg-primary/10 text-primary border-primary' : 'hover:bg-primary/5'
              }`}
              onClick={() => setPetType('cat')}
            >
              <Cat className="mr-2 h-4 w-4" />
              <span>{t('petInfo.cat')}</span>
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Button
              type="button"
              variant={petType === 'hamster' ? 'default' : 'outline'}
              className={`flex items-center justify-center py-2 px-3 ${
                petType === 'hamster' ? 'bg-primary/10 text-primary border-primary' : 'hover:bg-primary/5'
              }`}
              onClick={() => setPetType('hamster')}
            >
              <HamsterIcon className="mr-2 h-4 w-4" />
              <span>{t('petInfo.hamster') || '倉鼠'}</span>
            </Button>
            <Button
              type="button"
              variant={petType === 'parrot' ? 'default' : 'outline'}
              className={`flex items-center justify-center py-2 px-3 ${
                petType === 'parrot' ? 'bg-primary/10 text-primary border-primary' : 'hover:bg-primary/5'
              }`}
              onClick={() => setPetType('parrot')}
            >
              <Bird className="mr-2 h-4 w-4" />
              <span>{t('petInfo.parrot') || '鸚鵡'}</span>
            </Button>
          </div>
        </div>
        
        {/* Pet Weight */}
        <div className="mb-6">
          <div className="flex items-center">
            <Label htmlFor="pet-weight" className="block text-sm font-medium mb-2">
              {t('petInfo.weight')}
              <span className="text-xs text-muted-foreground ml-1">{weightUnit}</span>
            </Label>
          </div>
          <div className="relative rounded-md">
            <Input
              type="number"
              step="0.1"
              id="pet-weight"
              className="block w-full p-3 border border-gray-300 rounded-lg"
              placeholder={t('petInfo.weight')}
              value={petWeight === '' ? '' : petWeight}
              onChange={handleWeightChange}
              min="0.1"
            />
            <div className="absolute inset-y-0 right-0 flex items-center pr-3">
              <div className="inline-flex items-center cursor-pointer">
                <span className="mr-2 text-sm text-muted-foreground">kg</span>
                <Switch 
                  checked={weightUnit === 'lb'}
                  onCheckedChange={handleToggleUnit}
                  className="data-[state=checked]:bg-primary"
                />
                <span className="ml-2 text-sm text-muted-foreground">lb</span>
              </div>
            </div>
          </div>
        </div>

        {/* Life Stage Selection */}
        <div className="mb-6">
          <Label htmlFor="life-stage" className="block text-sm font-medium mb-2">{t('petInfo.lifeStage')}</Label>
          <Select 
            value={lifeStage} 
            onValueChange={setLifeStage}
          >
            <SelectTrigger id="life-stage" className="w-full p-3 border border-gray-300 rounded-lg">
              <SelectValue placeholder={t('petInfo.lifeStage')} />
            </SelectTrigger>
            <SelectContent>
              {lifeStageOptions.map((stage) => (
                <SelectItem key={stage.value} value={stage.value}>
                  {t(`lifeStage.${petType}.${stage.value}`) || stage.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        {/* Neutered Status */}
        <div className="mb-6">
          <Label className="block text-sm font-medium mb-2">{t('petInfo.isNeutered')}</Label>
          <RadioGroup
            value={isNeutered ? "yes" : "no"}
            onValueChange={(value) => setIsNeutered(value === "yes")}
            className="flex items-center"
          >
            <div className="flex items-center mr-6">
              <RadioGroupItem value="yes" id="neutered-yes" />
              <Label htmlFor="neutered-yes" className="ml-2">{t('petInfo.yes')}</Label>
            </div>
            <div className="flex items-center">
              <RadioGroupItem value="no" id="neutered-no" />
              <Label htmlFor="neutered-no" className="ml-2">{t('petInfo.no')}</Label>
            </div>
          </RadioGroup>
        </div>
        
        {/* Activity Level */}
        <div className="mb-6">
          <div className="flex items-center">
            <Label className="block text-sm font-medium mb-2">
              {t('petInfo.activityLevel')}
            </Label>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" className="p-0 h-auto ml-1">
                    <Info className="h-4 w-4 text-primary" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="text-sm">{t('petInfo.activityLevelTooltip')}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <Button
              type="button"
              variant={activityLevel === 'low' ? 'default' : 'outline'}
              className={`p-2 text-center ${
                activityLevel === 'low' ? 'bg-primary/10 text-primary border-primary' : 'hover:bg-primary/5'
              }`}
              onClick={() => setActivityLevel('low')}
            >
              {t('petInfo.low')}
            </Button>
            <Button
              type="button"
              variant={activityLevel === 'normal' ? 'default' : 'outline'}
              className={`p-2 text-center ${
                activityLevel === 'normal' ? 'bg-primary/10 text-primary border-primary' : 'hover:bg-primary/5'
              }`}
              onClick={() => setActivityLevel('normal')}
            >
              {t('petInfo.normal')}
            </Button>
            <Button
              type="button"
              variant={activityLevel === 'high' ? 'default' : 'outline'}
              className={`p-2 text-center ${
                activityLevel === 'high' ? 'bg-primary/10 text-primary border-primary' : 'hover:bg-primary/5'
              }`}
              onClick={() => setActivityLevel('high')}
            >
              {t('petInfo.high')}
            </Button>
          </div>
        </div>
        
        {/* Calculate Button */}
        <Button 
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium py-3 px-4 rounded-lg transition-all"
          onClick={handleCalculate}
        >
          <Calculator className="mr-2 h-5 w-5" /> {t('petInfo.calculateButton')}
        </Button>
      </Card>
    </div>
  );
};

// Custom calculator icon
const Calculator = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className} width="20" height="20">
    <rect x="4" y="2" width="16" height="20" rx="2" />
    <line x1="8" x2="16" y1="6" y2="6" />
    <line x1="8" x2="16" y1="10" y2="10" />
    <line x1="8" x2="12" y1="14" y2="14" />
    <line x1="8" x2="12" y1="18" y2="18" />
  </svg>
);

export default InputForm;
