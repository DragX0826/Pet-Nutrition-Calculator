import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Scale, HelpCircle, Calculator, ChevronRight } from 'lucide-react';
import { useLanguage } from '@/lib/languageContext';

const UnitConversionHelper: React.FC = () => {
  const { t, language } = useLanguage();
  const [open, setOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('weight');
  const [fromValue, setFromValue] = useState<string>('');
  const [fromUnit, setFromUnit] = useState<string>('kg');
  const [toUnit, setToUnit] = useState<string>('lb');
  const [result, setResult] = useState<string | null>(null);

  // 单位转换逻辑
  const convertUnit = (value: number, from: string, to: string): number => {
    // 定义转换系数
    const conversionFactors: Record<string, Record<string, number>> = {
      weight: {
        'kg_lb': 2.20462, // 千克 → 磅
        'lb_kg': 0.453592, // 磅 → 千克
        'kg_g': 1000, // 千克 → 克
        'g_kg': 0.001, // 克 → 千克
        'lb_oz': 16, // 磅 → 盎司
        'oz_lb': 0.0625, // 盎司 → 磅
        'g_oz': 0.035274, // 克 → 盎司
        'oz_g': 28.3495, // 盎司 → 克
      },
      energy: {
        'kcal_kJ': 4.184, // 千卡 → 千焦
        'kJ_kcal': 0.239006, // 千焦 → 千卡
      },
      volume: {
        'l_ml': 1000, // 升 → 毫升
        'ml_l': 0.001, // 毫升 → 升
        'cup_ml': 236.588, // 杯 → 毫升
        'ml_cup': 0.00422675, // 毫升 → 杯
        'tbsp_ml': 14.7868, // 汤匙 → 毫升
        'ml_tbsp': 0.067628, // 毫升 → 汤匙
        'tsp_ml': 4.92892, // 茶匙 → 毫升
        'ml_tsp': 0.202884, // 毫升 → 茶匙
      }
    };

    // 找到适当的转换系数
    let factor = 1;
    
    // 直接转换
    for (const category in conversionFactors) {
      const key = `${from}_${to}`;
      if (conversionFactors[category][key]) {
        factor = conversionFactors[category][key];
        break;
      }
    }
    
    // 如果没有直接转换，检查反向转换
    if (factor === 1) {
      for (const category in conversionFactors) {
        const reverseKey = `${to}_${from}`;
        if (conversionFactors[category][reverseKey]) {
          factor = 1 / conversionFactors[category][reverseKey];
          break;
        }
      }
    }
    
    // 执行转换
    return value * factor;
  };

  // 处理转换
  const handleConvert = () => {
    if (!fromValue || isNaN(Number(fromValue))) {
      setResult(t('unitConversion.invalidInput'));
      return;
    }
    
    const value = parseFloat(fromValue);
    const convertedValue = convertUnit(value, fromUnit, toUnit);
    
    // 格式化结果 (最多保留2位小数)
    setResult(`${value} ${fromUnit} = ${convertedValue.toFixed(2)} ${toUnit}`);
  };

  // 获取特定类型的单位选项
  const getUnitOptions = (type: string) => {
    switch (type) {
      case 'weight':
        return [
          { value: 'kg', label: t('unit.kilogram') || 'kg' },
          { value: 'g', label: t('unit.gram') || 'g' },
          { value: 'lb', label: t('unit.pound') || 'lb' },
          { value: 'oz', label: t('unit.ounce') || 'oz' },
        ];
      case 'energy':
        return [
          { value: 'kcal', label: t('unit.kcal') || 'kcal' },
          { value: 'kJ', label: t('unit.kJ') || 'kJ' },
        ];
      case 'volume':
        return [
          { value: 'l', label: t('unit.liter') || 'l' },
          { value: 'ml', label: t('unit.milliliter') || 'ml' },
          { value: 'cup', label: t('unit.cup') || 'cup' },
          { value: 'tbsp', label: t('unit.tablespoon') || 'tbsp' },
          { value: 'tsp', label: t('unit.teaspoon') || 'tsp' },
        ];
      default:
        return [];
    }
  };

  // 重置表单
  const resetForm = () => {
    setFromValue('');
    setResult(null);
  };

  // 处理标签切换
  const handleTabChange = (value: string) => {
    setActiveTab(value);
    const unitOptions = getUnitOptions(value);
    if (unitOptions.length >= 2) {
      setFromUnit(unitOptions[0].value);
      setToUnit(unitOptions[1].value);
    }
    resetForm();
  };

  // 单位互换
  const swapUnits = () => {
    const temp = fromUnit;
    setFromUnit(toUnit);
    setToUnit(temp);
    if (result) handleConvert(); // 如果有结果，自动重新计算
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2">
          <Scale className="h-4 w-4" />
          <span>{t('unitConversion.title') || 'Unit Conversion'}</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5 text-primary" />
            {t('unitConversion.title') || 'Unit Conversion Helper'}
          </DialogTitle>
          <DialogDescription>
            {t('unitConversion.description') || 'Convert between different units for pet nutrition calculations.'}
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="weight">{t('unitConversion.weight') || 'Weight'}</TabsTrigger>
            <TabsTrigger value="energy">{t('unitConversion.energy') || 'Energy'}</TabsTrigger>
            <TabsTrigger value="volume">{t('unitConversion.volume') || 'Volume'}</TabsTrigger>
          </TabsList>
          
          {/* Weight Tab Content */}
          <TabsContent value="weight" className="space-y-4">
            <div className="grid grid-cols-[2fr_1fr_auto_1fr] items-center gap-3">
              <div>
                <Label htmlFor="value-input">{t('unitConversion.value') || 'Value'}</Label>
                <Input
                  id="value-input"
                  type="number" 
                  step="0.01"
                  placeholder="0.00"
                  value={fromValue}
                  onChange={(e) => setFromValue(e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="from-unit">{t('unitConversion.from') || 'From'}</Label>
                <Select value={fromUnit} onValueChange={setFromUnit}>
                  <SelectTrigger id="from-unit">
                    <SelectValue placeholder={t('unitConversion.selectUnit') || 'Select unit'} />
                  </SelectTrigger>
                  <SelectContent>
                    {getUnitOptions('weight').map(unit => (
                      <SelectItem key={unit.value} value={unit.value}>{unit.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                variant="ghost" 
                size="icon" 
                className="mt-8"
                onClick={swapUnits}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
              
              <div>
                <Label htmlFor="to-unit">{t('unitConversion.to') || 'To'}</Label>
                <Select value={toUnit} onValueChange={setToUnit}>
                  <SelectTrigger id="to-unit">
                    <SelectValue placeholder={t('unitConversion.selectUnit') || 'Select unit'} />
                  </SelectTrigger>
                  <SelectContent>
                    {getUnitOptions('weight').map(unit => (
                      <SelectItem key={unit.value} value={unit.value}>{unit.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <Button onClick={handleConvert} className="w-full">
              {t('unitConversion.convert') || 'Convert'}
            </Button>
            
            {result && (
              <div className="py-3 px-4 bg-primary/5 border rounded-lg text-center font-medium">
                {result}
              </div>
            )}
            
            <div className="mt-4">
              <h4 className="text-sm font-medium mb-2">{t('unitConversion.conversionTable') || 'Conversion Table'}</h4>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t('unitConversion.from') || 'From'}</TableHead>
                    <TableHead>{t('unitConversion.to') || 'To'}</TableHead>
                    <TableHead>{t('unitConversion.multiply') || 'Multiply By'}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>kg</TableCell>
                    <TableCell>lb</TableCell>
                    <TableCell>2.20462</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>lb</TableCell>
                    <TableCell>kg</TableCell>
                    <TableCell>0.453592</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>g</TableCell>
                    <TableCell>oz</TableCell>
                    <TableCell>0.035274</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>oz</TableCell>
                    <TableCell>g</TableCell>
                    <TableCell>28.3495</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          </TabsContent>
          
          {/* Energy Tab Content */}
          <TabsContent value="energy" className="space-y-4">
            <div className="grid grid-cols-[2fr_1fr_auto_1fr] items-center gap-3">
              <div>
                <Label htmlFor="value-input">{t('unitConversion.value') || 'Value'}</Label>
                <Input
                  id="value-input"
                  type="number" 
                  step="0.01"
                  placeholder="0.00"
                  value={fromValue}
                  onChange={(e) => setFromValue(e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="from-unit">{t('unitConversion.from') || 'From'}</Label>
                <Select value={fromUnit} onValueChange={setFromUnit}>
                  <SelectTrigger id="from-unit">
                    <SelectValue placeholder={t('unitConversion.selectUnit') || 'Select unit'} />
                  </SelectTrigger>
                  <SelectContent>
                    {getUnitOptions('energy').map(unit => (
                      <SelectItem key={unit.value} value={unit.value}>{unit.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                variant="ghost" 
                size="icon" 
                className="mt-8"
                onClick={swapUnits}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
              
              <div>
                <Label htmlFor="to-unit">{t('unitConversion.to') || 'To'}</Label>
                <Select value={toUnit} onValueChange={setToUnit}>
                  <SelectTrigger id="to-unit">
                    <SelectValue placeholder={t('unitConversion.selectUnit') || 'Select unit'} />
                  </SelectTrigger>
                  <SelectContent>
                    {getUnitOptions('energy').map(unit => (
                      <SelectItem key={unit.value} value={unit.value}>{unit.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <Button onClick={handleConvert} className="w-full">
              {t('unitConversion.convert') || 'Convert'}
            </Button>
            
            {result && (
              <div className="py-3 px-4 bg-primary/5 border rounded-lg text-center font-medium">
                {result}
              </div>
            )}
            
            <div className="mt-4">
              <h4 className="text-sm font-medium mb-2">{t('unitConversion.energyInfo') || 'Energy Units in Pet Nutrition'}</h4>
              <p className="text-sm text-muted-foreground">
                {t('unitConversion.energyDescription') || 'Energy in pet food is commonly measured in kilocalories (kcal) or kilojoules (kJ). The daily energy requirement (DER) is typically expressed in kcal/day.'}
              </p>
              
              <Table className="mt-2">
                <TableHeader>
                  <TableRow>
                    <TableHead>{t('unitConversion.from') || 'From'}</TableHead>
                    <TableHead>{t('unitConversion.to') || 'To'}</TableHead>
                    <TableHead>{t('unitConversion.multiply') || 'Multiply By'}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>kcal</TableCell>
                    <TableCell>kJ</TableCell>
                    <TableCell>4.184</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>kJ</TableCell>
                    <TableCell>kcal</TableCell>
                    <TableCell>0.239006</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          </TabsContent>
          
          {/* Volume Tab Content */}
          <TabsContent value="volume" className="space-y-4">
            <div className="grid grid-cols-[2fr_1fr_auto_1fr] items-center gap-3">
              <div>
                <Label htmlFor="value-input">{t('unitConversion.value') || 'Value'}</Label>
                <Input
                  id="value-input"
                  type="number" 
                  step="0.01"
                  placeholder="0.00"
                  value={fromValue}
                  onChange={(e) => setFromValue(e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="from-unit">{t('unitConversion.from') || 'From'}</Label>
                <Select value={fromUnit} onValueChange={setFromUnit}>
                  <SelectTrigger id="from-unit">
                    <SelectValue placeholder={t('unitConversion.selectUnit') || 'Select unit'} />
                  </SelectTrigger>
                  <SelectContent>
                    {getUnitOptions('volume').map(unit => (
                      <SelectItem key={unit.value} value={unit.value}>{unit.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                variant="ghost" 
                size="icon" 
                className="mt-8"
                onClick={swapUnits}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
              
              <div>
                <Label htmlFor="to-unit">{t('unitConversion.to') || 'To'}</Label>
                <Select value={toUnit} onValueChange={setToUnit}>
                  <SelectTrigger id="to-unit">
                    <SelectValue placeholder={t('unitConversion.selectUnit') || 'Select unit'} />
                  </SelectTrigger>
                  <SelectContent>
                    {getUnitOptions('volume').map(unit => (
                      <SelectItem key={unit.value} value={unit.value}>{unit.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <Button onClick={handleConvert} className="w-full">
              {t('unitConversion.convert') || 'Convert'}
            </Button>
            
            {result && (
              <div className="py-3 px-4 bg-primary/5 border rounded-lg text-center font-medium">
                {result}
              </div>
            )}
            
            <div className="mt-4">
              <h4 className="text-sm font-medium mb-2">{t('unitConversion.volumeInfo') || 'Volume Units in Pet Feeding'}</h4>
              <p className="text-sm text-muted-foreground">
                {t('unitConversion.volumeDescription') || 'When measuring pet food, it\'s important to note that volume measurements can vary based on the density of the food. For accuracy, weight measurements are preferred.'}
              </p>
              
              <Table className="mt-2">
                <TableHeader>
                  <TableRow>
                    <TableHead>{t('unitConversion.from') || 'From'}</TableHead>
                    <TableHead>{t('unitConversion.to') || 'To'}</TableHead>
                    <TableHead>{t('unitConversion.multiply') || 'Multiply By'}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>cup</TableCell>
                    <TableCell>ml</TableCell>
                    <TableCell>236.588</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>tbsp</TableCell>
                    <TableCell>ml</TableCell>
                    <TableCell>14.7868</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>tsp</TableCell>
                    <TableCell>ml</TableCell>
                    <TableCell>4.92892</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter className="flex flex-col sm:flex-row gap-2">
          <Button variant="outline" onClick={resetForm}>
            {t('unitConversion.reset') || 'Reset'}
          </Button>
          <DialogClose asChild>
            <Button>{t('unitConversion.close') || 'Close'}</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default UnitConversionHelper;