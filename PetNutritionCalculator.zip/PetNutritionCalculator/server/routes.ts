import type { Express } from "express";
import { createServer, type Server } from "http";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  
  // API endpoint to get nutritional standards
  app.get('/api/nutrition-standards/:petType', (req, res) => {
    const { petType } = req.params;
    
    if (petType !== 'dog' && petType !== 'cat') {
      return res.status(400).json({ error: 'Invalid pet type. Must be "dog" or "cat".' });
    }
    
    const nutritionStandards = {
      dog: {
        protein: { min: 18, max: 30 },
        fat: { min: 10, max: 15 },
        carbohydrate: { min: 0, max: 50 }
      },
      cat: {
        protein: { min: 30, max: 45 },
        fat: { min: 15, max: 20 },
        carbohydrate: { min: 0, max: 30 }
      }
    };
    
    res.json(nutritionStandards[petType as 'dog' | 'cat']);
  });
  
  // API endpoint to get pet products recommendations
  app.get('/api/product-recommendations/:petType', (req, res) => {
    const { petType } = req.params;
    
    if (petType !== 'dog' && petType !== 'cat') {
      return res.status(400).json({ error: 'Invalid pet type. Must be "dog" or "cat".' });
    }
    
    const productRecommendations = {
      dog: [
        {
          id: 1,
          name: 'Premium Dog Formula',
          description: 'Ideal for adult dogs, balanced nutrition',
          rating: 4.7
        },
        {
          id: 2,
          name: 'Senior Dog Formula',
          description: 'Special blend for older dogs with joint support',
          rating: 4.5
        }
      ],
      cat: [
        {
          id: 1,
          name: 'Premium Cat Formula',
          description: 'Ideal for adult cats, balanced nutrition',
          rating: 4.8
        },
        {
          id: 2,
          name: 'Kitten Growth Formula',
          description: 'Enhanced with DHA for development',
          rating: 4.9
        }
      ]
    };
    
    res.json(productRecommendations[petType as 'dog' | 'cat']);
  });

  const httpServer = createServer(app);
  return httpServer;
}
